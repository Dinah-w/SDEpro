package com.example.polls.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.polls.payload.ItemPayload;
import com.example.polls.service.ItemService;

@RestController
@RequestMapping("/api")
public class ItemController {
	
	@Autowired
	private ItemService itemService;
	
    @PostMapping("/create-edit-item")
    public ResponseEntity<?> createItem(@Valid @RequestBody ItemPayload pollRequest) {
        return itemService.createItem(pollRequest);
    }

    
    @GetMapping("/get-items")
    public List<ItemPayload> getItem() {
        return  itemService.getItem();
    }

    
    @PostMapping("/delete-item")
    public ResponseEntity<?> deleteItem(@Valid @RequestBody ItemPayload pollRequest) {
        return itemService.deleteItem(pollRequest);
    }
    
    
    @GetMapping("/get-item-for-graph")
    public ItemPayload getItemForGraph() {
        return itemService.getItemForGraph();
    }
    
    

}
