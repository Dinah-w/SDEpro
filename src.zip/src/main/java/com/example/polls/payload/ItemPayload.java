package com.example.polls.payload;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ItemPayload {
	
	   private Long id;

	    
	    private String question;
	    
	    
	    private int itemAmount;
	    
	    private Date expenseDate;
	    
	    private String itemName;
	    
	    private Boolean isDeleted;
	    
	    private String category;
	    
	    private String _id;
	    
	    
	    private String formatDate;
	    
	    private List<String> dates = new ArrayList<String>();
		
	    private List<Integer> dateMoneys = new ArrayList<Integer>();
		
	    private int totalExpense;
	    
	    private Double average;
		
		public ItemPayload( List<String> dates, List<Integer> dateMoneys,int totalExpense,Double average) {
			this.dates = dates;
			this.dateMoneys = dateMoneys;
			this.totalExpense = totalExpense;
			this.average = average;
		}
	    
		public ItemPayload( int itemAmount, String formatDate) {
			this.itemAmount = itemAmount;
			this.formatDate = formatDate;
		}

		public ItemPayload(Long id, String question, int itemAmount, Date expenseDate,String formatDate, String itemName,
				Boolean isDeleted, String category, String _id) {
			
			this.id = id;
			this.question = question;
			this.itemAmount = itemAmount;
			this.expenseDate = expenseDate;
			this.formatDate = formatDate;
			this.itemName = itemName;
			this.isDeleted = isDeleted;
			this.category = category;
			this._id = _id;
		}

		public ItemPayload() {
		}

		public Long getId() {
			return id;
		}

		public String getFormatDate() {
			return formatDate;
		}

		public int getTotalExpense() {
			return totalExpense;
		}

		public void setTotalExpense(int totalExpense) {
			this.totalExpense = totalExpense;
		}

		public List<String> getDates() {
			return dates;
		}

		public void setDates(List<String> dates) {
			this.dates = dates;
		}

		
		public List<Integer> getDateMoneys() {
			return dateMoneys;
		}

		public void setDateMoneys(List<Integer> dateMoneys) {
			this.dateMoneys = dateMoneys;
		}

		public void setFormatDate(String formatDate) {
			this.formatDate = formatDate;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getQuestion() {
			return question;
		}

		public void setQuestion(String question) {
			this.question = question;
		}

		public int getItemAmount() {
			return itemAmount;
		}

		public void setItemAmount(int itemAmount) {
			this.itemAmount = itemAmount;
		}

	


		public Double getAverage() {
			return average;
		}

		public void setAverage(Double average) {
			this.average = average;
		}

		public Date getExpenseDate() {
			return expenseDate;
		}

		public void setExpenseDate(Date expenseDate) {
			this.expenseDate = expenseDate;
		}

		public String getItemName() {
			return itemName;
		}

		public void setItemName(String itemName) {
			this.itemName = itemName;
		}

		public Boolean getIsDeleted() {
			return isDeleted;
		}

		public void setIsDeleted(Boolean isDeleted) {
			this.isDeleted = isDeleted;
		}

		public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}

		public String get_id() {
			return _id;
		}

		public void set_id(String _id) {
			this._id = _id;
		}
	    
	    

}
