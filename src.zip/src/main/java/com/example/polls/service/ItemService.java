package com.example.polls.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.polls.model.Item;
import com.example.polls.payload.ApiResponse;
import com.example.polls.payload.ItemPayload;
import com.example.polls.repository.ItemRepository;

@Service
public class ItemService {
	
	@Autowired
	private ItemRepository itemRepository;
	
	
	
	public ResponseEntity<?> createItem(ItemPayload itemRequest){
		
		Optional<Item> item = itemRequest.getId() != null?
				itemRepository.findById(itemRequest.getId()):
					Optional.empty();
		
		Item create = item.isPresent()? item.get():new Item();
		
		
		System.out.println(itemRequest.getItemAmount());

		create.setQuestion(itemRequest.getQuestion());
		create.setItemAmount(itemRequest.getItemAmount());
		
		create.setExpenseDate(item.isPresent()?itemRequest.getExpenseDate():new Date());
		create.setItemName(itemRequest.getItemName());
		create.setIsDeleted(itemRequest.getIsDeleted());
		create.setCategory(itemRequest.getCategory());
		create.set_id(itemRequest.get_id());
		
		if(itemRepository.save(create) != null) {
			return new ResponseEntity(new ApiResponse(true, "Item Created Successfully"),HttpStatus.OK);
		}else {
			
			return new ResponseEntity(new ApiResponse(false, "Item Not Created"),HttpStatus.OK);	
		}
		
	}
	
	public List<ItemPayload> getItem(){
		List<ItemPayload> items = new ArrayList<ItemPayload>();

		for(Item item : itemRepository.findAll()) {
			
			String pattern = "MM-dd-yyyy";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			
			
			String date =item.getExpenseDate()!= null?
					simpleDateFormat.format(item.getExpenseDate()):"";
			
			items.add(new ItemPayload(
					item.getId(),
					item.getQuestion(),
					item.getItemAmount(),
					item.getExpenseDate(),
					date,
					item.getItemName(),
					item.getIsDeleted(),
					item.getCategory(),
					item.get_id()
					));
		}
		
		return items;
	}
	
	public ItemPayload getItemForGraph(){
		
		
		List<ItemPayload> items = new ArrayList<ItemPayload>();
		
		List<String> dates = new ArrayList<String>();
		
		List<Integer> dateMoneys = new ArrayList<Integer>();

		for(Item item : itemRepository.findAll()) {
			
			 int year=item.getExpenseDate().getYear();  
			 int currentYear=year+1900;  
			
			String pattern = "MM";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			
			String date =item.getExpenseDate()!= null?
					simpleDateFormat.format(item.getExpenseDate()):"";
			
			String deDate = date+"-01-"+currentYear;
			
			if(!dates.contains(deDate)) {
			dates.add(deDate);
			}
			
			items.add(new ItemPayload(
					item.getItemAmount(),
					deDate
					));
		}
		
		
		
		for(String myDates :dates.stream().distinct().collect(Collectors.toList()) ) {
			List<ItemPayload> dateItems = items.stream().filter(d -> d.getFormatDate().equals(myDates)).collect(Collectors.toList());
			int mySum = 0;
			if(dateItems.size()>0) {
				for(ItemPayload item :dateItems ) {
					mySum+=item.getItemAmount();
				}
				dateMoneys.add(mySum);
			}
		}
		
		int sum = 0;
	    for (int value : dateMoneys) {
	        sum += value;
	    }
	    
	    Double average = (double) (sum/dateMoneys.size());
		
		return new ItemPayload(dates,dateMoneys,sum,average);
	}
	
	
public ResponseEntity<?> deleteItem(ItemPayload itemRequest){
		Optional<Item> item = itemRequest.getId() != null?
				itemRepository.findById(itemRequest.getId()):
					Optional.empty();
		
		if(item.isPresent()) {
			try {
				itemRepository.delete(item.get());
				return new ResponseEntity(new ApiResponse(true, "Item  Deleted"),HttpStatus.OK);
			} catch (Exception e) {
				return new ResponseEntity(new ApiResponse(false, "Item Not Deleted"),HttpStatus.OK);
			}
		}else {
			return new ResponseEntity(new ApiResponse(false, "Item Not Found"),HttpStatus.OK);	
		}
}
	
	
	

}
